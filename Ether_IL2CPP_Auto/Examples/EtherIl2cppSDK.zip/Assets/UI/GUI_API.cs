﻿using Ether.Il2cpp;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GUI_API : MonoBehaviour
{
    public InputField impuniExe;
    public InputField impgame;
    public GameObject errPanel;
    public GameObject succPanel;
    // Start is called before the first frame update
    void Start()
    {
        //EtherIl2cppNative.CheckApiVersion();
    }

    public void install()
    {
        EtherIl2cppConfig config = EtherIl2cppConfig.Default;
        try
        {
            Il2cppInstaller.Install(impuniExe.text, config);
            Instantiate(succPanel);
        }
        catch(Exception ex)
        {
            Instantiate(errPanel).GetComponent<PanelText_Change>().SetText(ex.ToString());
        }
    }

    public void uninstall()
    {
        EtherIl2cppConfig config = EtherIl2cppConfig.Default;
        try
        {
            Il2cppInstaller.UnInstall(impuniExe.text);
            Instantiate(succPanel);
        }
        catch (Exception ex)
        {
            Instantiate(errPanel).GetComponent<PanelText_Change>().SetText(ex.ToString());
        }
    }

    public void enc_exe()
    {
        EtherIl2cppConfig config = EtherIl2cppConfig.Default;
        try
        {
            new ExeEncrypter(impgame.text, config).Process();
            Instantiate(succPanel);
        }
        catch (Exception ex)
        {
            Instantiate(errPanel).GetComponent<PanelText_Change>().SetText(ex.ToString());
        }
    }

    public void enc_and()
    {
        EtherIl2cppConfig config = EtherIl2cppConfig.Default;
        try
        {
            new ApkEncrypter(impgame.text, config).Process();
            Instantiate(succPanel);
        }
        catch (Exception ex)
        {
            Instantiate(errPanel).GetComponent<PanelText_Change>().SetText(ex.ToString());
        }
    }
}
