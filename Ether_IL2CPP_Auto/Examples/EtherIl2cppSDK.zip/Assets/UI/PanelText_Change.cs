﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PanelText_Change : MonoBehaviour
{
    public Text msgText;
    public void SetText(string text)
    {
        msgText.text = text;
    }

    public void Close()
    {
        Destroy(gameObject, 0.5f);
    }
}
